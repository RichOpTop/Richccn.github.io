# youtube_bot

This telegram bot base on python and allow you to download videos from YouTube.
There are three option:
1. Download entire videos on a youtube channel
2. Download choosen number of videos base on your key word
3. Download specific video


## To start :
1. Make your own telegram bon ot from Botfather
2. Paste token on telegram_youtube.py on line 9
3. Run the bot

## Required libraries:
Beautifulsoup : 'pip install beautifulsoup4' for linux 'pip3 install beautifulsoup4'
Python-telegram-bot : 'pip install python-telegram-bot' for linux 'pip3 install python-telegram-bot'
Scrapetube : 'pip install scrapetube' for linux 'pip3 install scrapetube'
Pytube : 'pip install pytube' for linux 'pip3 install pytube'
